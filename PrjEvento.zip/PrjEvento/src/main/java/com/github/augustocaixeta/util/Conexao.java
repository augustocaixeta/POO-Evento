package com.github.augustocaixeta.util;

import java.sql.Connection;

public class Conexao {
    Connection con = null;
    
    public Connection conexao() {
        return con;
    }
}

package com.github.augustocaixeta.principal;

import com.github.augustocaixeta.form.FormPrincipal;

public class Principal {
    public static void main(String[] args) {
        new FormPrincipal().setVisible(true);
    }
}

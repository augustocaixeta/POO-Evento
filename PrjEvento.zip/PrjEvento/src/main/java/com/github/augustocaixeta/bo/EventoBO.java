package com.github.augustocaixeta.bo;

import com.github.augustocaixeta.dao.EventoDAO;
import com.github.augustocaixeta.objeto.Evento;

public class EventoBO {
    EventoDAO eventoDAO;
    
    public EventoBO() {
        eventoDAO = new EventoDAO();
    }
    
    public Evento salvar(Evento evento) {
        return eventoDAO.salvar(evento);
    }
    
    public Evento editar(Evento evento) {
        return eventoDAO.editar(evento);
    }
    
    public int excluir(Evento evento) {
        return eventoDAO.excluir(evento);
    }
}

package com.github.augustocaixeta.dao;

import com.github.augustocaixeta.objeto.Evento;
import com.github.augustocaixeta.util.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EventoDAO {
    Connection con;
    
    public EventoDAO() {
        con = new Conexao().conexao();
    }
    
    public Evento salvar(Evento evento) {
        try (PreparedStatement ps = con.prepareStatement("INSERT INTO evento(nome, data_inicio, data_termino) VALUES (?, ?, ?);")) {
            ps.setString(1, evento.getNome());
            ps.setString(2, evento.getDataInicio());
            ps.setString(3, evento.getDataTermino());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                evento.setId(rs.getInt("id"));
            } else {
                evento.setId(-1);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return evento;
    }
    
    public Evento editar(Evento evento) {
        try (PreparedStatement ps = con.prepareStatement("UPDATE evento SET nome = ?, data_inicio = ?, data_termino = ? WHERE id = ?;")) {
            ps.setString(1, evento.getNome());
            ps.setString(2, evento.getDataInicio());
            ps.setString(3, evento.getDataTermino());
            ps.setInt(4, evento.getId());
            ps.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return evento;
    }
    
    public int excluir(Evento evento) {
        int sucesso = 0;
        try (PreparedStatement ps = con.prepareStatement("DELETE FROM evento WHERE id = ?;")) {
            ps.setInt(1, evento.getId());
            sucesso = ps.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return sucesso;
    }
}
